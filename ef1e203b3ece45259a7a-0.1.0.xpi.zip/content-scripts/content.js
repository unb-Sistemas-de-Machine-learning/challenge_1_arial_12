(function(){function e(e){return e}var t=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome;function n(e,t,n,r=()=>crypto.randomUUID()){let i=null,a=!1;function o(){i?.pendente&&t({tipo:`cancelar`,id:i.id}),i=null,a=!1}function s(t,s){o();let c=r();i={id:c,trecho:t,url:s,pendente:!0},n.carregando(t),e({tipo:`verificar`,id:c,trecho:t,url:s}).then(e=>{i?.id===c&&(i.pendente=!1,e?e.ok?(a=!1,n.veredito(e.veredito,t)):e.codigo!==`cancelada`&&(a=e.codigo===`falha_rede`,n.erro(e.codigo)):(a=!0,n.erro(`falha_rede`)))}).catch(()=>{i?.id===c&&(i.pendente=!1,a=!0,n.erro(`falha_rede`))})}function c(){i&&a&&s(i.trecho,i.url)}return{verificar:s,repetir:c,fechar:o}}var r={entrada_invalida:`Revise o texto selecionado e tente novamente.`,limite_excedido:`Muitas solicitações. Aguarde um pouco e tente novamente.`,openalex_indisponivel:`A busca de estudos está indisponível. Tente novamente mais tarde.`,busca_recusada:`Não foi possível buscar estudos para este trecho.`,triagem_indisponivel:`Não foi possível preparar a busca agora. Tente novamente em instantes.`,llm_timeout:`A análise demorou demais. Tente novamente.`,llm_indisponivel:`A análise está indisponível. Tente novamente mais tarde.`,recurso_nao_encontrado:`Serviço não encontrado.`,metodo_nao_permitido:`Esta operação não está disponível.`,erro_requisicao:`Não foi possível processar a solicitação.`,servico_indisponivel:`Serviço indisponível. Tente novamente mais tarde.`,erro_interno:`Não foi possível concluir a verificação agora.`,falha_rede:`Não foi possível conectar ao servidor. Tente novamente.`,cancelada:`Verificação cancelada.`};function i(e){return typeof e==`string`&&Object.prototype.hasOwnProperty.call(r,e)?r[e]:r.erro_interno}var a={sustenta:`Sustenta`,exagera:`Exagera`,nada_encontrado:`Nada encontrado`};function o(e){return e.replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e]??e)}function s(e,t){return`<div class="vc-topo">
    <span class="vc-badge vc-badge--${t}">${o(e)}</span>
    <button type="button" class="vc-fechar" aria-label="Fechar painel" title="Fechar">&times;</button>
  </div>`}function c(e){return`<p class="vc-trecho">“${o(e.length>180?`${e.slice(0,180)}…`:e)}”</p>`}function l(e){return`https://doi.org/${encodeURIComponent(e.trim()).replace(/%2F/gi,`/`)}`}function u(e){return s(`Verificando…`,`carregando`)+c(e)+`<p class="vc-just" role="status">Consultando os estudos…</p>`}var d=new Set([`falha_rede`,`triagem_indisponivel`]);function f(e){let t=typeof e==`string`&&d.has(e)?`<button type="button" class="vc-repetir">Tentar novamente</button>`:``;return s(`Erro`,`erro`)+`<p class="vc-just" role="alert">${o(i(e))}</p>`+t}function p(e,t){let n=e.estado,r=a[n]??`Erro`,i=Object.hasOwn(a,n)?n:`erro`,u=e.estudo,d=``;if(u){let e=u.ano==null?`Ano não informado`:String(u.ano),t=u.doi?.trim(),n=t?`<a class="vc-doi" href="${o(l(t))}" target="_blank" rel="noopener noreferrer">Abrir publicação (DOI: ${o(t)})</a>`:``,r=u.retratado?`<p class="vc-retratacao" role="note">⚠ Estudo retratado — confira a publicação antes de utilizar esta fonte.</p>`:``;d=`<section class="vc-estudo" aria-label="Estudo citado">
      <strong>${o(u.titulo)}</strong>
      <span class="vc-meta">${o(e)}</span>
      ${n}${r}
    </section>`}let f=e.termos.length?`<div class="vc-termos" aria-label="Termos relacionados">${e.termos.map(e=>`<span>${o(e)}</span>`).join(``)}</div>`:``,p=e.id==null?``:`<div class="vc-feedback" data-veredicto-id="${e.id}">
         <p>Este resultado foi útil?</p>
         <div class="vc-feedback-botoes">
           <button type="button" class="vc-feedback-btn vc-feedback-sim" data-util="true">Sim</button>
           <button type="button" class="vc-feedback-btn vc-feedback-nao" data-util="false">Não</button>
         </div>
       </div>`;return s(r,i)+c(t)+`<p class="vc-just">${o(e.justificativa)}</p>`+d+f+p}var m=e({matches:[`<all_urls>`,`file:///*`],runAt:`document_idle`,main(){let e=document.createElement(`div`);e.id=`verificador-cientifico-host`;let r=e.attachShadow({mode:`closed`});document.documentElement.appendChild(e),r.appendChild(h());let i=document.createElement(`button`);i.className=`vc-botao`,i.textContent=`Verificar`,i.hidden=!0,r.appendChild(i);let a=document.createElement(`div`);a.className=`vc-painel`,a.setAttribute(`role`,`dialog`),a.setAttribute(`aria-label`,`Resultado da verificação`),a.hidden=!0,r.appendChild(a);let o=n(e=>t.runtime.sendMessage(e),e=>{t.runtime.sendMessage(e).catch(()=>{})},{carregando(e){a.innerHTML=u(e),a.hidden=!1},veredito(e,t){a.innerHTML=p(e,t),a.hidden=!1},erro(e){a.innerHTML=f(e),a.hidden=!1}}),s=``;document.addEventListener(`mouseup`,t=>{t.composedPath().includes(e)||setTimeout(()=>{let e=window.getSelection(),t=e?.toString().trim()??``;if(t.length<10||!e||e.rangeCount===0){i.hidden=!0;return}s=t;let n=e.getRangeAt(0).getBoundingClientRect();i.style.top=`${Math.max(8,n.top-40)}px`,i.style.left=`${Math.max(8,n.left)}px`,i.hidden=!1},0)}),document.addEventListener(`mousedown`,t=>{t.composedPath().includes(e)||(i.hidden=!0)}),i.addEventListener(`click`,()=>{i.hidden=!0,o.verificar(s,location.href)}),a.addEventListener(`click`,e=>{let n=e.target;if(n.closest(`.vc-fechar`))o.fechar(),a.hidden=!0;else if(n.closest(`.vc-repetir`))o.repetir();else if(n.closest(`.vc-feedback-btn`)){let e=n.closest(`.vc-feedback-btn`),r=e.closest(`.vc-feedback`),i=Number(r.dataset.veredictoId),a=e.dataset.util===`true`;t.runtime.sendMessage({tipo:`feedback`,veredicto_id:i,util:a}),r.innerHTML=`<p class="vc-feedback-agradecimento">Obrigado pelo feedback!</p>`}})}});function h(){let e=document.createElement(`style`);return e.textContent=`
    :host { all: initial; }
    .vc-botao, .vc-painel {
      position: fixed; z-index: 2147483647;
      font: 13px/1.45 Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      color: #1d1d1d;
    }
    .vc-botao, .vc-repetir {
      border: 0; border-radius: 999px; background: #183fff;
      color: #fff; font-weight: 600; cursor: pointer;
    }
    .vc-botao { padding: 6px 12px; box-shadow: 0 2px 8px rgba(0,0,0,.28); }
    .vc-repetir { margin-top: 6px; padding: 7px 12px; }
    .vc-botao:hover, .vc-repetir:hover { background: #1231c9; }
    .vc-botao:focus-visible, .vc-repetir:focus-visible,
    .vc-fechar:focus-visible, .vc-doi:focus-visible {
      outline: 3px solid #183fff; outline-offset: 3px;
    }
    .vc-painel {
      right: 16px; bottom: 16px; width: min(340px, calc(100vw - 60px));
      max-height: 60vh; overflow: auto; padding: 12px 14px 14px;
      background: #fff; border: 1px solid #828282; border-radius: 10px;
      box-shadow: 0 8px 28px rgba(0,0,0,.22);
    }
    .vc-topo { display: flex; align-items: center; justify-content: space-between; }
    .vc-badge {
      color: #1d1d1d; font-weight: 700; font-size: 11px;
      letter-spacing: .04em; text-transform: uppercase;
      padding: 3px 8px; border-radius: 999px;
    }
    .vc-badge--sustenta { background: #27ae60; }
    .vc-badge--exagera { background: #f89a3c; }
    .vc-badge--nada_encontrado { background: #f9d159; }
    .vc-badge--erro { background: #eb5757; }
    .vc-badge--carregando { background: #828282; color: #fff; }
    .vc-fechar {
      border: 0; background: transparent; cursor: pointer;
      font-size: 18px; line-height: 1; color: #1d1d1d; padding: 0 2px;
    }
    .vc-trecho {
      margin: 10px 0 8px; color: #565656; font-style: italic;
      border-left: 3px solid #828282; padding-left: 8px;
    }
    .vc-just { margin: 8px 0; }
    .vc-estudo {
      margin-top: 10px; padding-top: 10px; border-top: 1px solid #d9d9d9;
      display: flex; flex-direction: column; gap: 4px;
    }
    .vc-meta { color: #565656; font-size: 12px; }
    .vc-doi { color: #1231c9; text-decoration: underline; overflow-wrap: anywhere; }
    .vc-retratacao {
      margin: 7px 0 0; padding: 7px 8px;
      border-left: 4px solid #eb5757; background: #fff1f1;
      color: #1d1d1d; font-weight: 600;
    }
    .vc-termos { margin-top: 10px; display: flex; flex-wrap: wrap; gap: 5px; }
    .vc-termos span {
      background: #ededed; border-radius: 999px; padding: 2px 8px; font-size: 11px;
    }
    .vc-feedback {
      margin-top: 12px; padding-top: 10px; border-top: 1px solid #e0e0e0;
      display: flex; flex-direction: column; gap: 8px; align-items: center;
    }
    .vc-feedback p { margin: 0; font-size: 12px; color: #565656; }
    .vc-feedback-botoes { display: flex; gap: 8px; }
    .vc-feedback-btn {
      border: 1px solid #d9d9d9; background: #fff; border-radius: 4px;
      padding: 4px 12px; cursor: pointer; font-size: 12px; font-weight: 500;
      transition: all 0.2s; color: #1d1d1d;
    }
    .vc-feedback-btn:hover { background: #f5f5f5; border-color: #828282; }
    .vc-feedback-sim:hover { background: #e8f5e9; border-color: #27ae60; color: #27ae60; }
    .vc-feedback-nao:hover { background: #ffebee; border-color: #eb5757; color: #eb5757; }
    .vc-feedback-agradecimento { font-weight: 600; color: #27ae60 !important; }
  `,e}var g={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},_=class e extends Event{static EVENT_NAME=v(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function v(e){return`${t?.runtime?.id}:content:${e}`}var y=typeof globalThis.navigation?.addEventListener==`function`;function b(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),y?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new _(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new _(e,t)),t=e)},1e3))}}}var x=class e{static SCRIPT_STARTED_MESSAGE_TYPE=v(`wxt:content-script-started`);id;abortController;locationWatcher=b(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return t.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?v(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),g.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{!(e instanceof CustomEvent)||!this.verifyScriptStartedEvent(e)||this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},S={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=m;return await e(new x(`content`,t))}catch(e){throw S.error(`The content script "content" crashed on startup!`,e),e}})()})();